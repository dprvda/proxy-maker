# @beamline/look-prism 0.2.0-rc.39

Generated from release content 83d39aa448cf5bf56c9b0890e59235e61d77295920225ad541838f328c1f0ec1.

Import @beamline/foundation/styles.css first, then selected look styles and this unit's styles.css where exported. Fonts and look setup are explicit choices.



The package contains catalog.json and beamline-release.json for installed-release guidance. Pure helper/type subpaths remain separate from client entries.
