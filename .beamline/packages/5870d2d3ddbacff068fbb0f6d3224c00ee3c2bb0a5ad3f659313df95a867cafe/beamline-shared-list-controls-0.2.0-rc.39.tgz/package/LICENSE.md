# Beamline UI Licence

Version 1.1, 12 October 2026. beamline.io/terms and beamline.io/licence summarise this licence; this text governs, subject
to mandatory rights. It is published at beamline.io/docs/licence.

## 1. Definitions

- **Product**: everything delivered as Beamline UI ("Beamline"): the source code, the compiled `@beamline/ui` package, styles, fonts
  configuration, examples, reference application, documentation, catalog, previews and agent instructions, in any
  version you receive.
- **Seller** ("we"): Danylo Pravda, Kyiv, Ukraine. Contact: hello@beamline.io.
- **You**: the one person whose Beamline account receives the purchase or credit redemption. If an organisation pays,
  the licence still gives access to only that person. Account access, the MCP server, installs, updates and the full
  library are personal and may not be shared.
- **End Product**: an application, website, internal tool or other software you or your client build, whose value to
  its users is mainly something other than the Product itself.
- **Third-party Material**: packages, fonts and other material that are not the Seller's work and come with their
  own licences, listed in the `THIRD-PARTY-LICENSES.md` file in each package and in `docs/DEPENDENCIES.md`.

## 2. What you may do

Once you purchase the Product or redeem Beamline credit for it, the Seller grants you a worldwide, non-exclusive,
non-transferable, perpetual licence to:

1. use, copy and modify the Product to design, build and maintain any number of End Products, your own and your
   clients', commercial ones included;
2. include the Product, modified or not, inside those End Products and distribute or host them, as long as the
   Product is not offered on its own (section 3);
3. let everyone working on an End Product (teammates, contractors and the client) use, edit, build and ship the
   Product code you installed into that End Product, as part of that End Product's codebase, without their own
   Beamline account. This permission applies to that End Product only;
4. use coding agents and AI tools on your projects that contain the Product. Your agent may use Beamline's MCP
   server on your behalf through your own account. Collaborators may use their tools on code already in the End
   Product under section 2.3; this does not give them access to Beamline's MCP server or library.

## 3. What you may not do

Only you may use your Beamline account, credentials, MCP access, downloads, installs, updates and full library.
Other people must buy their own licence to use Beamline's MCP server or library, or to take Beamline parts from an
End Product into other apps. Section 2.3 permits collaboration inside the app; it does not grant a separate library
licence or allow sharing the kit, account or credentials.

1. Sell, sublicense, share or give away the Product or a substantial part of it, modified or not, as a component
   library, UI kit, design system, template, theme, starter or similar product whose main value is the Product
   itself.
2. Publish the Product's source on its own, where it can be obtained apart from an End Product: a public code
   repository, a package registry or a file share.
3. Use the Product, or a substantial part of it, to build a dataset for training or fine-tuning a machine-learning
   model, or provide it to a service that does. Section 2.4 is not affected.
4. Remove or obscure the notices that Third-party Material requires, including the TradingView attribution that the
   price chart displays.

## 4. The free sample and Third-party Material

The parts published as Beamline's free sample under the MIT licence (github.com/dprvda/beamline) may be used under
either licence.

That free sample includes the shared runtime (including UIRoot), foundation (tokens, base CSS and helpers), and
Prism look. Its MIT licence permits copying, modifying and shipping those files as source in an application;
keep the copyright and permission notice, included with full-source installs as `licenses/free-sample-MIT.txt`.
Selected font files carry their own SIL Open Font License 1.1, included beside the fonts. Paid parts retain this
Beamline licence: sections 2 and 3 apply equally whether they are installed as packages or copied as source.

Third-party Material is licensed to you by its own authors under its own terms, not by this licence. The obligations
that reach your End Product are listed in the `THIRD-PARTY-LICENSES.md` file in each package and in
`docs/DEPENDENCIES.md`. Keep the required notices and visible attribution.

## 5. Updates

Your purchase includes new versions of the Complete System for as long as we publish it. We decide what future
versions contain; separate add-on packs may be sold separately and are not updates. Versions you receive remain
licensed to you if publication ends. No release schedule, new feature or support response time is promised.

## 6. Ownership

The Seller keeps all rights in the Product not granted here. You own your End Products and your changes, but your
changes to the Product's code remain under this licence wherever they contain the Product.

## 7. Warranty and liability

Subject to what the terms of sale promise (that the Product works as described, the refunds and the updates) and to
the law that applies, the Product is provided "as is". The trading components display data and collect order details;
they do not execute trades and are not financial advice. Demonstration data in the Product is invented.

If you buy as a business, the Seller is not liable for indirect or consequential losses, and the Seller's total
liability under this licence is limited to the amount you paid for it. Nothing here excludes liability for fraud,
death or personal injury caused by negligence, or liability that cannot lawfully be excluded or limited, and nothing
here limits rights that consumer law in your country gives you.

## 8. Termination

This licence ends if you materially breach it and do not put the breach right within 30 days of written notice. You
must then stop using the Product and delete copies of it, except inside End Products already delivered to users before
the breach, which may continue to run. A refund also ends the licence (beamline.io/refunds).

## 9. Law

This licence is governed by the law of Ukraine, and the courts of Kyiv have jurisdiction, without taking away the
protection that the law of your country of residence gives you as a consumer. Consumers keep any mandatory rights to
bring claims in their home courts.
